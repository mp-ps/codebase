rootProject.name = "curation-df"

