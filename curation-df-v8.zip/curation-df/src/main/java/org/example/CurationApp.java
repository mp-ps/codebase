package org.example;


import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.example.curation.composers.AccountPerformancePipelineComposer;
import org.example.curation.model.CurationConfig;
import org.example.curation.options.CurationOptions;
import org.yaml.snakeyaml.Yaml;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Map;

public class CurationApp {

    public static void main(String[] args) throws FileNotFoundException {


        PipelineOptionsFactory.register(CurationOptions.class);
        CurationOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(CurationOptions.class);
        Pipeline curation_one = Pipeline.create(options);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
//        String current_date = dateFormat.format(new Date());
        String current_date = "2024-06-14";

        InputStream inputStream = new FileInputStream(options.getConfigYaml());
        Yaml yaml = new Yaml();
        Map<String, Object> data = yaml.load(inputStream);
        final ObjectMapper mapper = new ObjectMapper();
        final CurationConfig config = mapper.convertValue(data, CurationConfig.class);

        AccountPerformancePipelineComposer composer = new
                AccountPerformancePipelineComposer(current_date, options, config);

        composer.compose(curation_one);
        curation_one.run().waitUntilFinish();

    }
}