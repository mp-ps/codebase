package org.example.curation.composers;

import com.google.api.services.bigquery.model.TableRow;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.transforms.Filter;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.values.*;
import org.example.curation.io.BQUpdate;
import org.example.curation.io.BQOperations;
import org.example.curation.model.CardnetAccounts;
import org.example.curation.model.CurationConfig;
import org.example.curation.options.CurationOptions;
import org.example.curation.transforms.SplitMIDDoFn;
import org.example.curation.util.Queries;

import java.util.List;

/* class PrintDoFn extends DoFn<CardnetAccounts, Void> {

    @ProcessElement
    public void processElement(@DoFn.Element CardnetAccounts input) throws IOException {
        System.out.println(input.getInternal_MID() + "," + input.getArea_of_Event() + "," + input.getReturn_Turnover_Month());
    }
}*/

public class AccountPerformancePipelineComposer {

    String currentDate;
    CurationOptions options;
    CurationConfig config;
    BQOperations bq;

    public AccountPerformancePipelineComposer(String currentDate, CurationOptions options, CurationConfig config){
        this.currentDate = currentDate;
        this.options = options;
        this.config = config;
    }

    public void compose(final Pipeline pipeline) {

         bq = new BQOperations();

         String[] srcTableNames = config.getCurationConfig().get("curation_1").getSrcTableName().split(",");
         String[] destTableNames = config.getCurationConfig().get("curation_1").getDestTableName().split(",");

         String accountPerformanceTable = srcTableNames[0];
         String monthlyPerformanceTable = destTableNames[0];

        String query = Queries.getCardnetAggDailyDataQuery(options.getProject(), options.getRawDatasetId(), accountPerformanceTable, currentDate);

        PCollection<CardnetAccounts> dailyAccounts= bq.read(pipeline,query,accountPerformanceTable)
                     .apply("TableRow to Accounts - 1", MapElements.into(
                                    TypeDescriptor.of(CardnetAccounts.class)).via(CardnetAccounts :: fromTableRow));

        query = Queries.getCardnetMonthlyAggQuery(options.getProject(), options.getStageDatasetId(), monthlyPerformanceTable);

        PCollectionView<List<CardnetAccounts>> monthlyAccountsList = bq.read(pipeline, query, monthlyPerformanceTable)
                .apply("TableRow to Accounts - 2", MapElements.into(
                        TypeDescriptor.of(CardnetAccounts.class)).via(CardnetAccounts :: fromTableRow))
                .apply(View.asList());


        SplitMIDDoFn splitObj = new SplitMIDDoFn(monthlyAccountsList);


        PCollectionTuple results = dailyAccounts.apply("Separate Existing and New MIDS",
                ParDo.of(splitObj).withSideInput("monthlyAccountsList",monthlyAccountsList)
                        .withOutputTags(splitObj.getNewMIDS(), TupleTagList.of(splitObj.getExistingMIDS())));

        // WriteToBQ
        PCollection<TableRow> insertMIDS = results.get(splitObj.getNewMIDS());
        String tableSpec = options.getProject() + ":" + options.getStageDatasetId() + "." + monthlyPerformanceTable;
        bq.write(insertMIDS, tableSpec);

        // UpdateToBQ
        PCollection<TableRow> updateMIDS = results.get(splitObj.getExistingMIDS());
        updateMIDS.apply("Update BQ - CardnetMonthlyPerformance ", ParDo.of(new BQUpdate(options.getProject(), options.getStageDatasetId(), monthlyPerformanceTable, bq)));

    }
}
