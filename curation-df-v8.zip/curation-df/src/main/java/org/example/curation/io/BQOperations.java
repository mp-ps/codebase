package org.example.curation.io;

import com.google.api.services.bigquery.model.TableRow;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.JobInfo;
import com.google.cloud.bigquery.QueryJobConfiguration;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.values.PCollection;

import java.io.Serializable;

public class BQOperations implements Serializable {

    public PCollection<TableRow> read(Pipeline pipeline, String query, String tableName) {
        String stepName = String.format("Read: %s", tableName);
//        System.out.println(query); //Logger
        return pipeline.apply(stepName,  BigQueryIO.readTableRows()
                .fromQuery(query)
                .usingStandardSql().withMethod(BigQueryIO.TypedRead.Method.DIRECT_READ));

    }

    public void write(PCollection<TableRow> rows, String tableSpec) {
        String stepName = String.format("Write: %s", tableSpec.split("\\.")[1]);
        rows.apply(stepName, BigQueryIO.writeTableRows().
                to(tableSpec)
                .withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_NEVER)
                .withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));
    }

    public void update(QueryJobConfiguration queryConfig, BigQuery bigQuery) throws Exception {
        Job queryJob = bigQuery.create(JobInfo.newBuilder(queryConfig).build());
        queryJob = queryJob.waitFor();

        if (queryJob.getStatus().getError() != null) {
            throw new Exception(queryJob.getStatus().getError().toString());

        }

    }

}
