package org.example.curation.io;

import com.google.api.services.bigquery.model.TableRow;
import com.google.cloud.bigquery.*;
import org.apache.beam.sdk.transforms.DoFn;
import org.example.curation.util.Constants;
import org.example.curation.util.Queries;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;

public class BQUpdate extends DoFn<TableRow, Void> implements Serializable {

    String projectId;
    String datasetId;
    String tableName;
    BQOperations bq;

    public BQUpdate(String projectId, String datasetId, String tableName, BQOperations bq) {
        this.projectId = projectId;
        this.datasetId = datasetId;
        this.tableName = tableName;
        this.bq = bq;
    }

    @ProcessElement
    public void processElement(ProcessContext c) throws Exception {

      final BigQuery bigQuery = BigQueryOptions.newBuilder().setProjectId(projectId).build().getService();
        String updateQuery = Queries.getCardnetMonthlyUpdateQuery(projectId, datasetId, tableName);

        QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(updateQuery)
                .addNamedParameter(Constants.GROSS_TURNOVER_MONTH, QueryParameterValue.numeric(BigDecimal.valueOf(Double.parseDouble(c.element().getOrDefault(Constants.GROSS_TURNOVER_MONTH,0.0).toString()))))
                .addNamedParameter(Constants.GROSS_TRANSACTIONS_MONTH, QueryParameterValue.int64(Long.valueOf(c.element().getOrDefault(Constants.GROSS_TRANSACTIONS_MONTH,0).toString())))
                .addNamedParameter(Constants.RETURN_TURNOVER_MONTH, QueryParameterValue.numeric(BigDecimal.valueOf(Double.parseDouble(c.element().getOrDefault(Constants.RETURN_TURNOVER_MONTH,0.0).toString()))))
                .addNamedParameter(Constants.RETURN_TRANSACTIONS_MONTH,QueryParameterValue.int64(Long.valueOf(c.element().getOrDefault(Constants.RETURN_TRANSACTIONS_MONTH,0).toString())))
                .addNamedParameter(Constants.INTERNAL_MID, QueryParameterValue.string(c.element().getOrDefault(Constants.INTERNAL_MID,"").toString()))
                .addNamedParameter(Constants.REPORTING_MONTH, QueryParameterValue.string(c.element().getOrDefault(Constants.REPORTING_MONTH,"").toString()))
                .addNamedParameter(Constants.AREA_OF_EVENT, QueryParameterValue.string(c.element().getOrDefault(Constants.AREA_OF_EVENT,"").toString()))
                .addNamedParameter(Constants.CHANNEL, QueryParameterValue.string(c.element().getOrDefault(Constants.CHANNEL,"").toString()))
                .addNamedParameter(Constants.CP_CNP, QueryParameterValue.string(c.element().getOrDefault(Constants.CP_CNP,"").toString()))
                .addNamedParameter(Constants.PRODUCT_ID, QueryParameterValue.int64(Long.valueOf(c.element().getOrDefault(Constants.PRODUCT_ID,0).toString())))
                .addNamedParameter(Constants.SUBMISSION_ROUTE, QueryParameterValue.string(c.element().getOrDefault(Constants.SUBMISSION_ROUTE,"").toString()))
                .addNamedParameter(Constants.UPDATE_TIMESTAMP, QueryParameterValue.string(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(System.currentTimeMillis())))
                .addNamedParameter(Constants.DATE_FORMAT, QueryParameterValue.string("%Y-%m-%d"))
                .build();

        bq.update(queryConfig, bigQuery);

    }

}
