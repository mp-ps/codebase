package org.example.curation.model;

import com.google.api.services.bigquery.model.TableRow;
import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;

import java.math.BigDecimal;

@DefaultCoder(AvroCoder.class)
public class CardnetAccounts {

    String Internal_MID;
    String Reporting_Month;
    String Area_of_Event;
    String Channel;
    String CP_CNP;
    String Product_Id;
    String Submission_Route;
//    String Standard_Card_Type;
//    String Commercial_Credit_Card;
    BigDecimal Gross_Turnover_Month;
    int Gross_Transactions_Month;
    BigDecimal Return_Turnover_Month;
    int Return_Transactions_Month;


    public static CardnetAccounts fromTableRow(TableRow row) {
        CardnetAccounts accounts = new CardnetAccounts();
        System.out.println(row.toString());

        accounts.Internal_MID = (String) row.getOrDefault("Internal_MID","");
        accounts.Reporting_Month = (String) row.getOrDefault("Reporting_Month","");
        accounts.Area_of_Event = (String) row.getOrDefault("Area_of_Event","");
        accounts.Channel = (String) row.getOrDefault("Channel","");
        accounts.CP_CNP = (String) row.getOrDefault("CP_CNP","");
        accounts.Product_Id = (String) row.getOrDefault("Product_Id", "");
        accounts.Submission_Route = (String) row.getOrDefault("Submission_Route", "");
//        accounts.Standard_Card_Type = (String) row.getOrDefault("Standard_Card_Type","");
//        accounts.Commercial_Credit_Card = "";
        accounts.Gross_Turnover_Month = BigDecimal.valueOf(Double.parseDouble(row.getOrDefault("Gross_Turnover_Month","0.0").toString()));
        accounts.Gross_Transactions_Month = Integer.parseInt(row.getOrDefault("Gross_Transactions_Month","0").toString());
        accounts.Return_Turnover_Month = BigDecimal.valueOf(Double.parseDouble( row.getOrDefault("Return_Turnover_Month","0.0").toString()));
        accounts.Return_Transactions_Month = Integer.parseInt( row.getOrDefault("Return_Transactions_Month",0).toString());

        return accounts;
    }

    public String getReporting_Month(){
        return Reporting_Month;
    }

    public String getInternal_MID() {
        return Internal_MID;
    }

    public String getArea_of_Event() {
        return Area_of_Event;
    }

    public String getChannel() {
        return Channel;
    }

    public String getCP_CNP() {
        return CP_CNP;
    }

    public String getProduct_Id() {
        return Product_Id;
    }

    public String getSubmission_Route() {
        return Submission_Route;
    }

//    public String getStandard_Card_Type() {
//        return Standard_Card_Type;
//    }
//
//    public String getCommercial_Credit_Card(){
//        return Commercial_Credit_Card;
//    }

    public BigDecimal getGross_Turnover_Month() {
        return Gross_Turnover_Month != null ? Gross_Turnover_Month: new BigDecimal("0.0");
    }

    public int getGross_Transactions_Month() {
        return Gross_Transactions_Month;
    }

    public BigDecimal getReturn_Turnover_Month() {
        return Return_Turnover_Month != null ? Return_Turnover_Month: new BigDecimal("0.0");
    }

    public int getReturn_Transactions_Month() {
        return Return_Transactions_Month;
    }


}
