package org.example.curation.model;

import lombok.*;
import org.apache.beam.sdk.coders.DefaultCoder;
import org.apache.beam.sdk.coders.SerializableCoder;

import java.io.Serializable;
import java.util.List;
import java.util.Map;


@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CurationConfig {

    private Map<String, TableConfig> curationConfig;

    public Map<String, TableConfig> getCurationConfig() {
        return curationConfig;
    }

    @DefaultCoder(SerializableCoder.class)
    @Setter
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class TableConfig implements Serializable {
        private String srcTableName;
        private String destTableName;

        public String getSrcTableName() {
            return srcTableName;
        }

        public String getDestTableName() {
            return destTableName;
        }
    }

}
