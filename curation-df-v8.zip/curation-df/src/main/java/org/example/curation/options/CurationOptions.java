package org.example.curation.options;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;

public interface CurationOptions extends DataflowPipelineOptions {

    String getRawDatasetId();

    void setRawDatasetId(String datasetId);

    String getStageDatasetId();

    void setStageDatasetId(String stageDatasetId);

    String getConfigYaml();

    void setConfigYaml(String configYaml );

}
