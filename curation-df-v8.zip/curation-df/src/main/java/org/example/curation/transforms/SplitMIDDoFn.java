package org.example.curation.transforms;

import com.google.api.services.bigquery.model.TableRow;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.TupleTag;
import org.example.curation.model.CardnetAccounts;
import org.example.curation.util.Constants;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Objects;

public class SplitMIDDoFn extends DoFn<CardnetAccounts, TableRow> {

    private final PCollectionView<List<CardnetAccounts>> monthlyAccountsView;

    public SplitMIDDoFn(PCollectionView<List<CardnetAccounts>> view){
        this.monthlyAccountsView = view;
    }

    private final TupleTag<TableRow> existingMIDS = new TupleTag<>(){};
    private final TupleTag<TableRow> newMIDS = new TupleTag<>(){};


    @ProcessElement
    public void processElement(ProcessContext processContext){

        final List<CardnetAccounts> monthlyAccountsList = processContext.sideInput(monthlyAccountsView);
        CardnetAccounts accountPresent = getIfCardnetAccountExist(monthlyAccountsList, processContext.element());
        String currentTimeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(System.currentTimeMillis());
        TableRow tableRow;
        if(accountPresent != null){
            System.out.println("Matched ####"); // Write Logger here
            tableRow = getTableRow(accountPresent, Objects.requireNonNull(processContext.element()));
            tableRow.set("Update_Timestamp",currentTimeStamp);
            processContext.output(existingMIDS,tableRow);
        } else {
            System.out.println("##### Not matched "); //Write Logger here
            tableRow = getTableRow(new CardnetAccounts(), Objects.requireNonNull(processContext.element()));
            tableRow.set("Insert_Timestamp", currentTimeStamp);
            tableRow.set("Update_Timestamp",currentTimeStamp);
            processContext.output(tableRow);
        }
    }


    public CardnetAccounts getIfCardnetAccountExist(List<CardnetAccounts> monthlyAccountsList, CardnetAccounts dailyAccount){

        return monthlyAccountsList.stream().filter(mAccount ->
                            (mAccount.getInternal_MID().equals(dailyAccount.getInternal_MID())) &&
                                    mAccount.getReporting_Month().equals(dailyAccount.getReporting_Month()) &&
                                    mAccount.getArea_of_Event().equals(dailyAccount.getArea_of_Event()) &&
                                    mAccount.getCP_CNP().equals(dailyAccount.getCP_CNP()) && mAccount.getChannel().equals(dailyAccount.getChannel()))
                    .findFirst().orElse(null);
    }

    private static TableRow getTableRow(CardnetAccounts oldAccount, CardnetAccounts newAccount) {
        TableRow tableRow = new TableRow();

        tableRow.set(Constants.INTERNAL_MID, newAccount.getInternal_MID());
        tableRow.set(Constants.REPORTING_MONTH, newAccount.getReporting_Month());
        tableRow.set(Constants.AREA_OF_EVENT, newAccount.getArea_of_Event());
        tableRow.set(Constants.CHANNEL, newAccount.getChannel());
        tableRow.set(Constants.CP_CNP, newAccount.getCP_CNP());
        tableRow.set(Constants.PRODUCT_ID, newAccount.getProduct_Id());
//        tableRow.set("Standard_Card_Type", account.getStandard_Card_Type());
        tableRow.set(Constants.SUBMISSION_ROUTE, newAccount.getSubmission_Route());
//        tableRow.set("Commercial_Credit_Card", account.getCommercial_Credit_Card());
        tableRow.set(Constants.GROSS_TURNOVER_MONTH, newAccount.getGross_Turnover_Month().add(oldAccount.getGross_Turnover_Month()));
        tableRow.set(Constants.GROSS_TRANSACTIONS_MONTH, newAccount.getGross_Transactions_Month() + oldAccount.getGross_Transactions_Month());
        tableRow.set(Constants.RETURN_TURNOVER_MONTH, newAccount.getReturn_Turnover_Month().add(oldAccount.getReturn_Turnover_Month()));
        tableRow.set(Constants.RETURN_TRANSACTIONS_MONTH,  newAccount.getReturn_Transactions_Month() +  oldAccount.getReturn_Transactions_Month());
        return tableRow;
    }

    public TupleTag<TableRow> getExistingMIDS(){
        return existingMIDS;
    }

    public TupleTag<TableRow> getNewMIDS(){
        return newMIDS;
    }

}
