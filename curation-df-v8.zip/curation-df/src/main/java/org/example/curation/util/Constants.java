package org.example.curation.util;

public class Constants {

    private Constants(){}

    public static final String PROJECT = "project";
    public static final String DATASET = "dataset";
    public static final String TABLE = "table";

    /*
    Table Column Names
     */
    public static final String INTERNAL_MID = "Internal_MID";
    public static final String REPORTING_MONTH = "Reporting_Month";
    public static final String AREA_OF_EVENT = "Area_of_Event";
    public static final String CHANNEL = "Channel";
    public static final String CP_CNP = "CP_CNP";
    public static final String PRODUCT_ID = "Product_Id";
    public static final String SUBMISSION_ROUTE = "Submission_Route";
    public static final String STANDARD_CARD_TYPE = "Standard_Card_Type";
    public static final String COMMERCIAL_CREDIT_CARD = "Commercial_Credit_Card";
    public static final String GROSS_TURNOVER_MONTH = "Gross_Turnover_Month";
    public static final String GROSS_TRANSACTIONS_MONTH = "Gross_Transactions_Month";
    public static final String RETURN_TURNOVER_MONTH = "Return_Turnover_Month";
    public static final String RETURN_TRANSACTIONS_MONTH ="Return_Transactions_Month";
    public static final String UPDATE_TIMESTAMP = "Update_Timestamp";
    public static final String INSERT_TIMESTAMP = "Insert_Timestamp";


    public static final String DATE_FORMAT = "Date_Format";

}
