package org.example.curation.util;

public class Queries {

    public static String getCardnetAggDailyDataQuery(String projectId, String datasetId, String table_name, String currentDate) {

        String query = String.format("SELECT Internal_MID, \n" +
                "       DATE_TRUNC(Post_Date, MONTH) AS Reporting_Month,\n" +
                "       Area_of_Event, \n" +
                "       Channel,\n" +
                "       CP_CNP,\n" +
                "       Product_Id,\n" +
                "       Submission_Route,\n" +
                "       FORMAT('%s',SUM(Gross_Sales)) AS Gross_Turnover_Month, \n" +
                "       SUM(Gross_Transactions) AS Gross_Transactions_Month, \n" +
                "       FORMAT('%s',SUM(Return_Sales)) AS Return_Turnover_Month,\n" +
                "       SUM(Return_Transactions) AS Return_Transactions_Month\n" +
                "FROM %s.%s.%s \n" +
//                "WHERE DATE(Meta_Insert_Timestamp) = '%s' AND \n" +
                "WHERE Internal_MID IS NOT NULL AND \n" +
                "Post_Date IS NOT NULL AND \n" +
                "Area_of_Event IS NOT NULL AND \n" +
                "Channel IS NOT NULL AND \n" +
                "CP_CNP IS NOT NULL AND \n" +
                "Product_Id IS NOT NULL \n" +
                "GROUP BY Internal_MID, \n" +
                "        Reporting_Month, \n" +
                "        Area_of_Event,\n" +
                "        Channel, \n" +
                "        CP_CNP,\n" +
                "        Product_Id,\n" +
                "        Submission_Route; ","%06f","%06f", projectId, datasetId, table_name, currentDate);

        System.out.println(query);
        return query;
    }

    public static String getCardnetMonthlyAggQuery(String projectId, String datasetId, String tableName){
        return String.format("SELECT Internal_MID," +
                        "Reporting_Month, \n" +
                        "Area_of_Event, \n" +
                        "Channel, \n" +
                        "CP_CNP, \n" +
                        "Product_Id, \n" +
                        "Submission_Route, \n" +
//                        "Standard_Card_Type, \n" +
                        "Commercial_Credit_Card, \n" +
                        "Gross_Turnover_Month,\n" +
                        " Gross_Transactions_Month, \n" +
                        "Return_Turnover_Month, \n" +
                        "Return_Transactions_Month \n" +
                        "FROM %s.%s.%s",
                projectId, datasetId, tableName);

    }


    public static String getCardnetMonthlyUpdateQuery(String projectId, String datasetId, String tableName) {

        return String.format("UPDATE `%s.%s.%s` \n" +
                       " SET Gross_Turnover_Month=@Gross_Turnover_Month, \n " +
                       "     Gross_Transactions_Month=@Gross_Transactions_Month, \n" +
                       "     Return_Turnover_Month=@Return_Turnover_Month, \n" +
                       "     Return_Transactions_Month=@Return_Transactions_Month, \n" +
                       "     Update_Timestamp=@Update_Timestamp \n" +
                       "WHERE Internal_MID= @Internal_MID \n" +
                       "   AND Reporting_Month= PARSE_DATE(@Date_Format,@Reporting_Month) \n" +
                       "   AND Area_of_Event= @Area_of_Event \n" +
                       "   AND Channel= @Channel \n" +
                       "   AND CP_CNP= @CP_CNP \n" +
                       "   AND Product_Id= @Product_Id", projectId,datasetId,tableName);
    }


}
